/**
 * 
 */
package edu.unah.poo;

import java.time.LocalDate;

/**
 * @author Tiffany
 *
 */
public class Perro extends Animal{
	
    //Constructor
	public Perro(String nombre, LocalDate fechaNacimiento) {
		super(nombre, fechaNacimiento);
		
	}

	@Override
	public void hablar() {
		// TODO Auto-generated method stub
		
	}

    

}
