package edu.unah.poo;

public interface AccionesComunes {
	
	public void dormir();
	public void alimentarse();
	public void hablar();

}
