/**
 * 
 */
package edu.unah.poo;

import java.time.LocalDate;

/**
 * @author Tiffany
 *
 */
public class Gato extends Animal{
	
	//Constructor
	public Gato(String nombre, LocalDate fechaNacimiento) {
		super(nombre, fechaNacimiento);
	}

	@Override
	public void hablar() {
		// TODO Auto-generated method stub
		
	}

}
