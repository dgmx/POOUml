package edu.unah.poo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CompaniaPesqueraApplicationTests {

	@Test
	void contextLoads() {
	}

}
