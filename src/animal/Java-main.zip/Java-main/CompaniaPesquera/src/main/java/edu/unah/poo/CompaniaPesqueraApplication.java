package edu.unah.poo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CompaniaPesqueraApplication {

	public static void main(String[] args) {
		SpringApplication.run(CompaniaPesqueraApplication.class, args);
	}

}
